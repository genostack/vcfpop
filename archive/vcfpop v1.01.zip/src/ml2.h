/* Maximum-likelihood estimation of relatedness coefficient for polyploids */

#pragma once
#include "vcfpop.h"

void MLRelatednessAssign2(int sumploidy, double *f, int *a, double *c, int IBS);